<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="adminpanel.css">
  <style>

    @keyframes bounceIn {
        0%, 20%, 50%, 80%, 100% {
            transform: translateY(0);
            opacity: 1;
        }
        40% {
            transform: translateY(-30px);
            opacity: 0.8;
        }
        60% {
            transform: translateY(-15px);
            opacity: 0.8;
        }
    }

    .icon i {
        animation: bounceIn 1.5s ease-in-out; 
        transition: transform 0.3s ease-in-out; 
    }

    .icon i:hover {
        transform: scale(2.2); 
    }

    body {
            margin: 0;
        }

        #customer-reviews {
            max-width: 600px;
            margin: auto;
            background: url('image/reviews.jpg') center center fixed no-repeat;
            background-size: cover; 
            background-position: center; 
            color: black;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #reviewCarousel {
            margin-top: 20px;
        }

        .carousel-control-prev, .carousel-control-next {
            width: 5%;
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            font-size: 2rem;
            color: #fff;
        }

        .carousel-inner {
            border-radius: 10px;
            overflow: hidden;
        }

        .carousel-item {
            padding: 20px;
            color: black; 
        }

        .kpi-section {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
        }

        .kpi-item {
         background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
         text-align: center;
        width: 200px;
         margin: 10px;
        transition: box-shadow 0.3s ease-in-out;
        }

       .kpi-item:hover {
       box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
       }

      .kpi-card {
       display: flex;
      align-items: center;
      }

     .kpi-icon {
     flex: 1;
     }

    .kpi-icon i {
    color: #4B70E2;
    font-size: 59px; 
    }

    .kpi-details {
    flex: 2;
    text-align: left;
    padding-left: 10px;
    }

   .kpi-details h4 {
    margin-bottom: 5px;
    }

    #totalAdmins {
    margin: 0;
    font-weight: bold;
    font-size: 59px; 
    }








</style>


</head>
<body>

<div class="admin-panel clearfix">
  <div class="slidebar">
    <div class="logo">
      <a href="adminprofile.php"></a>
      <link rel="stylesheet" href="adminpanel.css">
    </div>
    <ul>
      <li><a href="#dashboard" id="targeted" style="font-family: 'Montserrat', sans-serif; color:#4b70e2;">dashboard<i class="fas fa-users"></i></a></li>
      <li><a href="loader5.html" style="font-family: 'Montserrat', sans-serif; color:red;">admin<i class="fas fa-user-cog"></i></a></li>
      <li><a href="loader6.html" style="font-family: 'Montserrat', sans-serif; color:green;">customer<i class="fas fa-users"></i></a></li>
      <li><a href="loader7.html" style="font-family: 'Montserrat', sans-serif; color:brown;">product<i class="fas fa-box"></i></a></li>
      <li><a href="loader8.html" style="font-family: 'Montserrat', sans-serif; color:purple;">orders<i class="fas fa-shopping-cart"></i></a></li>
      <li><a href="loader9.html" style="font-family: 'Montserrat', sans-serif; color:rgb(207, 207, 79);">payment<i class="fas fa-credit-card"></i></a></li>
      <li><a href="category.php" style="font-family: 'Montserrat', sans-serif; color:goldenrod">categories<i class="fas fa-filter"></i></a></li>
      <li><a href="salesreport.php" style="font-family: 'Montserrat', sans-serif; color:orange;">sales report<i class="fas fa-chart-bar"></i></a></li>
      <li><a href="viewrequest.php" style="font-family: 'Montserrat', sans-serif; color:grey;">request<i class="fas fa-envelope"></i></a></li>
      <li><a href="superadminlogin.php" style="font-family: 'Montserrat', sans-serif; color:black;">Superadmin Login</i></a></li>
    </ul>
  </div>
  <div class="main">
    <ul class="topbar clearfix">
      <li><a href="#">n</a></li>
      <li><a href="#">p</a></li>
      <li><a href="#">o</a></li>
      <li><a href="#">q</a></li>
      <li><a href="superadminregister.php">Superadmin</a></li>
    </ul>
    <div class="mainContent clearfix">
      <div id="dashboard">
        <h2 class="header" style="color: #4b70e2;"><span class="icon"></span>Dashboard</h2>
    
        <h2 class="header" style="color:#4b70e2; margin-top: 60px;">
            <span class="icon">
                <a href="loader5.html">
                  <i class="fas fa-user-cog fa-3x" style="color: yellowgreen;"></i>
                 <span>Admin</span>
                </a>
            </span>
    
            <span class="icon" style="margin-left: 130px;">
                <a href="loader6.html">
                  <i class="fas fa-users fa-3x" style="color: orange;"></i>
                  <span>Customer</span>
                </a>
            </span>
    
            <span class="icon" style="margin-left: 130px;">
                <a href="loader7.html">
                  <i class="fas fa-box fa-3x" style="color: #4b70e2;"></i>
                  <span>Product</span>    
                </a>
            </span>
    
            <span class="icon" style="margin-left: 130px;">
                <a href="loader8.html">
                  <i class="fas fa-list fa-3x" style="color: green;"></i>  
                  <span>Orders</span>
                </a>
            </span>

        </h2>
          
          <h2 class="header" style="color:#4b70e2; margin-top: 60px;">

            <span class="icon">
              <a href="loader9.html">
                <i class="fas fa-credit-card fa-3x" style="color: orangered;"></i>  
                <span>Payments</span>
              </a>
          </span>

          <span class="icon" style="margin-left: 130px;">
            <a href="category.php">
              <i class="fas fa-filter fa-3x" style="color : goldenrod ;"></i>
              <span>Categories</span>
            </a>
        </span>

          <span class="icon" style="margin-left: 130px;">
              <a href="salesreport.php">
                <i class="fas fa-chart-bar fa-3x" style="color: palevioletred;"></i>
                <span>Sales Report</span>
              </a>
          </span>

          <span class="icon" style="margin-left: 100px;">
            <a href="viewrequest.php ">
              <i class="fas fa-envelope fa-3x" style="color: grey;"></i>
              <span>Request</span>
            </a>
        </span>

        </h2>

  

        <div id="customer-reviews" class="container mt-4">
          <h3 class="text-center mb-4">Customer Reviews</h3>
                

          <div id="reviewCarousel" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                  <div class="carousel-item active">
                      <p class="text-center"><strong>Nice</strong></p>
                      <p class="text-center">Great product! I really liked it.</p>
                  </div>
                  <div class="carousel-item">
                      <p class="text-center"><strong>Not bad</strong></p>
                      <p class="text-center">Pls add more books.</p>
                  </div>
                  
              </div>
      
              <a class="carousel-control-prev" href="#reviewCarousel" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#reviewCarousel" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
              </a>
          </div>
      </div>

      
      <div class="kpi-item">
        <div class="kpi-card">
            <div class="kpi-icon">
                <i class="fas fa-user-cog fa-3x" style="color: greenyellow;"></i>
            </div>
            <div class="kpi-details">
                <h4>Total Admins</h4>
                <p id="totalAdmins">Loading...</p>
            </div>
        </div>
    </div>








       </div>


       <div id="posts">
         <h2 class="header" style="color: #4b70e2;"></h2>
       </div>
       <div id="media">
         <h2 class="header" style="color: #4b70e2;"></h2>
       </div>
       <div id="pages">
         <h2 class="header" style="color: #4b70e2;"></h2>
       </div>
       <div id="links">
         <h2 class="header" style="color: #4b70e2;"></h2>
       </div>
       <div id="new">
        <h2 class="header" style="color: #4b70e2;"></h2>
      </div>
       <div id="comments">
         <h2 class="header" style="color: #4b70e2;"></h2>
       </div>

     </div>
     <ul class="statusbar">
       <li><a href=""></a></li>
       <li><a href=""></a></li>
       <li class="profiles-setting"><a href="superadminlogin.php">s</a></li>
       <li class="logout"><a href="adminregisterlogin.html" style="font-family: 'Montserrat', sans-serif; color:#4b70e2;">Logout</a></li>
     </ul>
   </div>

   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
   <script src="addadmin.js"></script>

   </div>

</div>