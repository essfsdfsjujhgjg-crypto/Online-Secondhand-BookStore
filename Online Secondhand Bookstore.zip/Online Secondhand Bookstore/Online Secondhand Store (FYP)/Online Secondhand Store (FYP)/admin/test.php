<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Admin Panel</title>

</head>
<body>
<div class="admin-panel clearfix">
    <div class="slidebar">
        <div class="logo">
            <a href="adminpanel.css"></a>
            <link rel="stylesheet" href="adminpanel.css">
        </div>
        <ul>
            <li><a href="?section=dashboard" id="targeted" style="font-family: 'Montserrat', sans-serif; color:#4b70e2;">dashboard</a></li>
            <li><a href="?section=posts" style="font-family: 'Montserrat', sans-serif; color:red;">admin</a></li>
            <li><a href="?section=media" style="font-family: 'Montserrat', sans-serif; color:green;">customer</a></li>
            <li><a href="?section=pages" style="font-family: 'Montserrat', sans-serif; color:brown;">product</a></li>
            <li><a href="?section=links" style="font-family: 'Montserrat', sans-serif; color:purple;">orders</a></li>
            <li><a href="?section=comments" style="font-family: 'Montserrat', sans-serif; color:orange;">sales report</a></li>
        </ul>
    </div>
    <div class="main">
        <ul class="topbar clearfix">
            <li><a href="#">q</a></li>
            <li><a href="#">p</a></li>
            <li><a href="#">o</a></li>
            <li><a href="#">f</a></li>
            <li><a href="#">n</a></li>
        </ul>
        <div class="mainContent clearfix">
            <div id="dashboard">
                <h2 class="header" style="color: #4b70e2;"><span class="icon"></span>Dashboard</h2>
                <div class="monitor">
                    <h4>Right Now</h4>
                    <div class="clearfix">
                        <ul class="content">
                            <li>content</li>
                            <li class="posts"><span class="count">179</span><a href="">posts</a></li>
                            <li class="pages"><span class="count">13</span><a href="">pages</a></li>
                            <li class="categories"><span class="count">21</span><a href="">categories</a></li>
                            <li class="tags"><span class="count">305</span><a href="">tags</a></li>
                        </ul>
                        <ul class="discussions">
                            <li>discussions</li>
                            <li class="comments"><span class="count">353</span><a href="">comments</a></li>
                            <li class="approved"><span class="count">319</span><a href="">approved</a></li>
                            <li class="pending"><span class="count">0</span><a href="">pending</a></li>
                            <li class="spam"><span class="count">34</span><a href="">spam</a></li>
                        </ul>
                    </div>
                    <p>Theme <a href="">Twenty Eleven</a> with <a href="">3 widgets</a></p>
                </div>
                <div class="quick-press">
                    <h4>Quick Press</h4>
                    <form action="" method="post">
                        <input type="text" name="title" placeholder="Title"/>
                        <input type="text" name="content" placeholder="Content"/>
                        <input type="text" name="tags" placeholder="Tags"/>
                        <button type="button" class="save">l</button>
                        <button type="button" class="delet">m</button>
                        <button type="submit" class="submit" name="submit">Publish</button>
                    </form>
                </div>
            </div>
            <div id="posts">
                <h2 class="header" style="color: #4b70e2;">Admin</h2>
                 <?php include 'adminmanagement.php'; ?>
            </div>

            <div id="media">
                <h2 class="header" style="color: #4b70e2;">User</h2>
                <?php
                // Your PHP logic for handling the 'media' section goes here
                ?>
            </div>
            
            <div id="pages">
                <h2 class="header" style="color: #4b70e2;">Product</h2>
                <?php
                // Your PHP logic for handling the 'media' section goes here
                ?>
            </div>

            <div id="links">
                <h2 class="header" style="color: #4b70e2;">Orders</h2>
                <?php
                // Your PHP logic for handling the 'media' section goes here
                ?>
            </div>

            <div id="comments">
                <h2 class="header" style="color: #4b70e2;">Sales Report</h2>
                <?php
                // Your PHP logic for handling the 'media' section goes here
                ?>
            </div>

        </div>
        <ul class="statusbar">
       <li><a href=""></a></li>
       <li><a href=""></a></li>
       <li class="profiles-setting"><a href="">s</a></li>
       <li class="logout"><a href="loader2.html" style="font-family: 'Montserrat', sans-serif; color:#4b70e2;">Logout</a></li>
     </ul>
    </div>
</div>
</body>
</html>
